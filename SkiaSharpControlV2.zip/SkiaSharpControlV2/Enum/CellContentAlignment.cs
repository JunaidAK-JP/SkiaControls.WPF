﻿
namespace SkiaSharpControlV2.Enum
{
    public enum CellContentAlignment
    {
        Left,
        Center,
        Right
    }
}
