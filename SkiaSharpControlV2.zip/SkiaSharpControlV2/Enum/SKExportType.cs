﻿namespace SkiaSharpControlV2.Enum
{
    public enum SKExportType
    {
        All,
        Selected
    }
}
